const db = require("../models");
const NewPlot = db.newPlot;
const Countplot = db.countplot;
const {objectId} = require("mongodb");


// Post api for plot-details...!
exports.Createplotdetails = async (req,res) => {
    Countplot.findOneAndUpdate (
        {id: "autovalue"},
        {"$inc": {"sequence":1}},
        {new: true},(err,cd) => {
            let seqId;
            if (cd == null){
                const newval = new Countplot(
                    {
                    id: "autovalue",
                    sequence: 1
                    }
                )
                newval.save()
                seqId=1
            }else{
                seqId=cd.sequence
            }
            const {farmerName,location,village,district,latitude,long,area_of_Plot,perimeter_of_Plot,plotShape,soilType,waterSource,nutrient_Content_Analysis,plotid,farmerId} = req.body
            try {
                const Plotdetails = new NewPlot ({
                    farmerName,
                    location,
                    village,
                    district,
                    latitude,
                    long,
                    area_of_Plot,
                    perimeter_of_Plot,
                    plotShape,
                    soilType,
                    nutrient_Content_Analysis,
                    waterSource,
                    plotid,
                    farmerId,
                    countPlot: seqId
                })

                Plotdetails 
                    .save()
                    .then((data) => { 
                        console.log(data)
                        return res.status(201).json({
                            status: true,
                            message: "successfully created....!",
                            data,
                        });
                    })
                    .catch((error) => {
                        console.log(error);
                        return res.status(400).json({
                            status: false,
                            message: "Something went wrong. your name is repeated..",
                            error,
                        })
                    })
            } catch (err) {
                res.status(401).json({
                    message: err
                })
            }
        }
    )
}


// Edit/update plot-details api ...!
exports.updatePlot = async (req,res) => {
    try {
        const EditPlot = await NewPlot.findOneAndUpdate({_id: req.params.plotId},{
            $set:{
                farmerName: req.body.farmerName,
                location: req.body.location,
                village: req.body.village,
                district: req.body.district,
                latitude: req.body.latitude,
                long: req.body.long,
                area_of_Plot: req.body.area_of_Plot,
                perimeter_of_Plot: req.body.perimeter_of_Plot,
                plotShape: req.body.plotShape,
                soilType: req.body.soilType,
                nutrient_Content_Analysis: req.body.nutrient_Content_Analysis,
                waterSource: req.body.waterSource,
                plotid: req.body.plotid,
                farmerId: req.body.farmerId
            }
        },{new: true})
        // console.log(req.params.id,"eeeee")
        return res.status(200).json({
                updated: "updated successfully",
                EditPlot
            })
    }catch (err) {
        return res.status(400).json({
            error : err
        })
    }
}


// Get api for List for plot-details...!
exports.GetPlot = async (req,res) => {
    try{
        const getplot = await NewPlot.find({})
        if (getplot){
            return res.status(201).json({
                status: true,
                message: `here are your ${getplot.length} data` ,
                getplot
            })
        }else {
            return res.status(400).json({
                status: false,
                message: "your cluster is not available.." , 
                    err
            })
        }
    }catch (err){
        console.log(err)
        return res.status(404).json({
            error: err
        })
    }
}


// get api by plotId for plot details...!
exports.getPlotId = async (req,res) => {
    try {
        // const getfarmername = await NewFarmers.findOne({farmerId: req.params.farmerId})
        // console.log(getfarmername,"ggggggg")
        // if (getfarmername){
        //     const farmer_id = getfarmername.FarmerId
        //     const getplotid = await NewPlot.findOne({FarmerId: farmer_id})
        //     if (getplotid){
        //         return res.status(201).json({
        //             status: true,
        //             message: getplotid
        //         })
        //     }else{
        //         return res.status(400).json({
        //             status: false,
        //             message: "plot is not available ..!"
        //         })
        //     }
        // }
        const getplotid = await NewPlot.findOne({farmerId: req.params.FarmerId})
        console.log(getplotid,"ggggggg")
        if (getplotid){
            return res.status(201).json({
                status: true,
                message: getplotid
            })
        }else{
            return res.status(400).json({
                status: false,
                message: "plot is not available ..!"
            })
        }
    } catch (err) {
        console.log(err)
        return res.status(400).json({
            error: err
        })
    }
}



// delete api for plot-details...!
exports.deleteplot_details = async (req,res) => {
    try {
        const plot_details = await NewPlot.deleteOne({_id: req.params._id})
        console.log(plot_details, "pppp")
        if (plot_details){
            return res.status(201).json({
                deleted: "plot deleted successfully"
            })
        }
    }catch (err){
        console.log(err)
        return res.status(400).json({
            error : err
        })
    }
} 