const db = require("../models");
const Newstate = db.newstate;

// post Api for state schema..
exports.createState = async (req,res) => {
    try{
        const {state} = req.body;
        const addstate = new Newstate({
            state
        })
    
        addstate
            .save()
            .then((data) => {
                res.status(200).json({
                    status: true,
                    message: "successfully created..",
                        data
                })
            })
            .catch((error) => {
                console.log(error)
                res.status(404).json({
                    status: 400,
                    error: error
                })
            })
    }catch (err) {
        res.status(400).json({
            error: err
        })
    }
}


// get api for state...
exports.getState = async (req,res) => {
    try {
        const getstate = await Newstate.find({});
        if (getstate){
            res.status(200).json({
                message: getstate
            })
        }else {
            res.status(400).json({
                error: "data is no longer available"
            })
        }
    }catch (error) {
        res.status(400).json({
            error: error
        })
    }
}