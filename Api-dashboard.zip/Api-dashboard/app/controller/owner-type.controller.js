const db = require("../models");
const Newownertype = db.newownertype;

// post api for onwer-type..!
exports.createOwnertype = async (req,res) => {
    try{
        const {ownerType} = req.body;
        const addOwnertype = new Newownertype({
            ownerType
        })

        addOwnertype
            .save()
            .then((data) => {
                res.status(200).json({
                    message: "successfully created",
                    data
                })
            })
            .catch((err) => {
                res.status(400).json({
                    err: "missed while posting data", err
                })
            })
    }catch (error){
        res.status(400).json({
            error: error
        })
    }
}


// get api for ownertype...
exports.getOwnertype = async (req,res) => {
    try{
        const getowner = await Newownertype.find({});
        if (getowner){
            res.status(201).json({
                message: getowner
            })
        }else{
            res.status(400).json({
                err: "you don't have data"
            })
        }
    }catch (error){
        res.status(404).json({
            err: error
        })
    }
}