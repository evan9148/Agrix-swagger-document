const db = require("../models");
const NewCluster = db.newCluster;
const Clustercount = db.clustercount;
const { objectId } = require("mongodb");

//  Post api for Cluster...!
exports.CreateCluster = async (req, res) => {
    Clustercount.findOneAndUpdate(
        { id: "autovalue" },
        { "$inc": { "sequence": 1 } },
        { new: true }, (err, cd) => {
            let seqId;
            if (cd == null) {
                const newval = new Clustercount(
                    {
                        id: "autovalue",
                        sequence: 1
                    }
                )
                newval.save()
                seqId = 1
            } else {
                seqId = cd.sequence
            }


            const {
                clusterCode,
                clusterid,
                clusterManager,
                addVillages,
                district,
                state,
                officeAddress,
                contactDetails, clusterLevelStat:
                [{
                    customerStat,
                    sales,
                    purchase,
                    expenditure,
                    hrBasicdetails,
                    lead_Details
                }]
            } = req.body

            try {
                const Clusterdetails = new NewCluster({
                    clusterCode,
                    clusterid,
                    clusterManager,
                    addVillages,
                    district,
                    state,
                    officeAddress,
                    contactDetails,
                    clusterLevelStat: [{
                        customerStat,
                        sales,
                        purchase,
                        expenditure,
                        hrBasicdetails,
                        lead_Details
                    }],
                    countCluster: seqId,

                })

                Clusterdetails
                    .save()
                    .then((data) => {
                        console.log(data)
                        return res.status(201).json({
                            status: true,
                            message: "successfully created....!",
                            data,
                        });
                    })
                    .catch((error) => {
                        console.log(error);
                        return res.status(400).json({
                            status: false,
                            message: "Something went wrong.you might missed any of fields please check it ...",
                            error,
                        })
                    })
            } catch (err) {
                res.status(401).json({
                    message: err
                })
            }
        }
    )
}


// Edit/update cluster api ...!
exports.updateCluster = async (req, res) => {
    try {
        const EditCluster = await NewCluster.findOneAndUpdate({ _id: req.params.idcluster }, {
            $set: {
                clusterCode: req.body.clusterCode,
                clusterid: req.body.clusterid,
                clusterManager: req.body.clusterManager,
                addVillages: req.body.addVillages,
                district: req.body.district,
                state: req.body.state,
                officeAddress: req.body.officeAddress,
                contactDetails: req.body.contactDetails,
                clusterLevelStat: [{
                    customerStat: req.body.customerStat,
                    sales: req.body.sales,
                    purchase: req.body.purchase,
                    expenditure: req.body.expenditure,
                    hR_basic_details: req.body.hR_basic_details,
                    lead_Detail: req.body.lead_Details
                }]
            }
        }, { new: true })
        return res.status(200).json({
            updated: "updated successfully",
            EditCluster
        })
    } catch (err) {
        return res.status(400).json({
            error: err
        })
    }
}


// Get api for List for cluster...!
exports.GetCluster = async (req, res) => {
    try {
        const getcluster = await NewCluster.find({})
        if (getcluster) {
            return res.status(201).json({
                status: true,
                message: `here are your ${getcluster.length} data`,
                getcluster
            })
        } else {
            return res.status(400).json({
                status: false,
                message: "your cluster is not available.."
            })
        }
    } catch (err) {
        console.log(err)
        return res.status(404).json({
            error: err
        })
    }
}


// get api by clusterid for cluster ...
exports.GetClusterbyclusterid = async (req, res) => {
    try {
        const getcluster = await NewCluster.findOne({ clusterid: req.params.clusterid })
        console.log(getcluster, "ggggg")
        if (getcluster) {
            return res.status(201).json({
                status: true,
                message: getcluster
            })
        }
        // else {
        //     return res.status(400).json({
        //         status: false,
        //         message: "your cluster is not available.."
        //     })
        // }...
    } catch (err) {
        console.log(err)
        return res.status(404).json({
            error: err
        })
    }
}


// Delete api for Cluster...!
exports.deleteCluster = async (req, res) => {
    try {
        const cluster_details = await NewCluster.deleteOne({ _id: req.params._id })
        console.log(cluster_details, "ccccccccccccc")
        if (cluster_details) {
            return res.status(200).json({
                deleted: "cluster deleted successfully"
            })
        }
    } catch (err) {
        console.log(err)
        return res.status(400).json({
            error: err
        })
    }
} 