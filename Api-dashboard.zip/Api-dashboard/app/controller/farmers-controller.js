const db = require("../models");
const NewFarmers = db.newFarmers;
const FarmerCount = db.farmerCount;
const {objectId} = require("mongodb");


// Post api for farmer..!
exports.CreateFarmers = async (req,res) => {
    FarmerCount.findOneAndUpdate(
        {id: "autovalue"},
        {"$inc": {"sequence":1}},
        {new: true},(err,cd) => {
            let seqId;
            if (cd == null){
                const newval = new FarmerCount(
                    {
                    id: "autovalue",
                    sequence: 1
                    }
                )
                newval.save()
                seqId=1
            }else{
                seqId=cd.sequence
            }

            const {
                firstName,
                lastName,
                ownerType,
                address,
                farmingSeason,
                cropType,
                cropSubType,
                farmerId,
                contactNo,
                clusterId
            } = req.body
            try {
                const Farmersdetails = new NewFarmers ({
                    firstName,
                    lastName,
                    ownerType,
                    address,
                    farmingSeason,
                    cropType,
                    cropSubType,
                    farmerId,
                    contactNo,
                    clusterId,
                    countFarmer: seqId
                })

                Farmersdetails 
                    .save()
                    .then((data) => {
                        console.log(data)
                        return res.status(201).json({
                            status: true,
                            message: "successfully created....!",
                            data,
                        });
                    })
                    .catch((error) => {
                        console.log(error);
                        return res.status(400).json({
                            status: false,
                            message: "Something went wrong.you might missed any of fields please check it ...",
                            error,
                        })
                    })
            } catch (err) {
                console.log(err)
                res.status(401).json({
                    message: err
                })
            }
        }
    )
}


// Edit/update farmer api...!
exports.updateFarmers = async (req,res) => {
    try {
        const EditFarmer = await NewFarmers.findOneAndUpdate({_id: req.params.Farmerid},{
            $set:{
                firstName: req.body.firstName,
                lastName: req.body.lastName,
                ownerType: req.body.ownerType,
                address: req.body.address,
                farmingSeason: req.body.farmingSeason,
                cropType: req.body.cropType,
                cropSubType: req.body.cropSubType,
                farmerId: req.body.farmerId,
                contactNo:req.body.contactNo,
                clusterId:req.body.clusterId


            }
        },{new: true})
        return res.status(200).json({
                updated: "updated successfully",
                EditFarmer
            })
    }catch (err) {
        return res.status(400).json({
            error : err
        })
    }
}


// Get api for List for farmers...!
exports.GetFarmers = async (req,res) => {
    try{
        const getfarmer = await NewFarmers.find({})
        if (getfarmer){
            return res.status(201).json({
                status: true,
                message: `here are your ${getfarmer.length} data` ,
                getfarmer
            })
        }else {
            return res.status(400).json({
                status: false,
                message: "your data is not available.." , 
                    err
            })
        }
    }catch (err){
        console.log(err)
        return res.status(404).json({
            error: err
        })
    }
}



// get api by Farmer id..!
exports.getFarmersName = async (req,res) => {
    try {
        const getfarmername = await NewFarmers.findOne({_id: req.params.Farmerid})
        console.log(getfarmername,"ggggggg")
        if (getfarmername){
            return res.status(201).json({
                status: true,
                message: getfarmername
            })
        }else{
            return res.status(400).json({
                status: false,
                message: "farmer not available ..!"
            })
        }
    } catch (err) {
        console.log(err)
        return res.status(400).json({
            error: err
        })
    }
}


// Get api by clusterId..!
exports.farmerByClusterId = async (req,res) => {
    try {
        const farmerByCluster = await NewFarmers.find({clusterId: req.params.clusterId})
        console.log(farmerByCluster,"ggggggg")
        if (farmerByCluster){
            return res.status(201).json({
                status: true,
                message: farmerByCluster
            })
        }else{
            return res.status(400).json({
                status: false,
                message: "There is no any Farmer in this Cluster..!"
            })
        }
    } catch (err) {
        console.log(err)
        return res.status(400).json({
            error: err
        })
    }
}

// delete api for Farmers...!
exports.deleteFarmer = async (req,res) => {
    try {
        const farmer_details = await NewFarmers.deleteOne({_id: req.params._id})
        console.log(farmer_details,"dddddddd")
        if (farmer_details){
            return res.status(200).json({
                deleted: "farmer deleted successfully"
            })
        }else {
            return res.status(404).json({
                message: "your data is not available.."
            })
        }
    }catch (err){
        console.log(err)
        return res.status(400).json({
            error : err
        })
    }
}