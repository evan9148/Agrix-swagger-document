const db = require("../models");
const Newdistrict = db.newdistrict;

// post api for district...
exports.createDistrict = async (req,res) => {
    try{
        const {district} = req.body;
        const addDistrict = new Newdistrict({
            district
        })

        addDistrict
            .save()
            .then((data) => {
                res.status(201).json({
                    message: "successfully created",
                    data
                })
            })
            .catch((error) => {
                res.status(404).json({
                    error: "might missed while posting your data",error
                })
            })

    }catch (err){
        res.status(400).json({
            error: err
        })
    }
}


// get api for state...
exports.getDistrict = async (req,res) => {
    try {
        const getdistrict = await Newdistrict.find({});
        if (getdistrict){
            res.status(200).json({
                message: getdistrict
            })
        }else {
            res.status(400).json({
                error: "data is no longer available"
            })
        }
    }catch (error) {
        res.status(400).json({
            error: error
        })
    }
}