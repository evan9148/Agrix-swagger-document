const db = require("../models");
const NewDrivers = db.newDriver;
const Counter = db.counter;
const { objectId } = require("mongodb");

// Post api for driver..!
exports.createDriver = async (req, res) => {
  Counter.findOneAndUpdate(
    {id: "autovalue"},
    {"$inc": {"sequence":1}},
    {new: true},(err,cd) => {
      let seqId;
      if (cd == null){
        const newval = new Counter(
          {
            id: "autovalue",
            sequence: 1
          }
        )
        newval.save()
        seqId=1
      }else{
        seqId=cd.sequence
      }

      const {
        driverId,
        firstName,
        lastName,
        contactDetails,
        state,
        clusterId,
        machineId,
        attachementId,
        CountDriver
      } = req.body;
      try {
        const Driverdetails = new NewDrivers({
          driverId,
          firstName,
          lastName,
          contactDetails,
          state,
          clusterId,
          machineId,
          attachementId,
          CountDriver: seqId
        });
    
        Driverdetails.save()
          .then((data) => {
            console.log(data);
            return res.status(201).json({
              status: true,
              message: "Successfully Created....!",
              data,
            });
          })
          .catch((error) => {
            console.log(error);
            return res.status(400).json({
              status: false,
              message:
                "Something went wrong.you might missed any of fields please check it ...",
              error,
            });
          });
      } catch (err) {
        console.log(err);
        res.status(401).json({
          message: err,
        });
      }
    }
  )
};

// Edit/update  Driver Api By its Object ID(_id)...!
exports.updateDrivers = async (req, res) => {
  try {
    const EditDriver = await NewDrivers.findOneAndUpdate(
      { _id: req.params._id },
      {
        $set: {
          driverId: req.body.driverId,
          firstName: req.body.firstName,
          lastName: req.body.lastName,
          contactDetails: req.body.contactDetails,
          state: req.body.state,
          clusterId: req.body.clusterId,
          machineId: req.body.implementId,
          attatchementId: req.body.attatchementId
        },
      },
      { new: true }
    );
    return res.status(200).json({
      updated: "updated successfully",
      EditDriver,
    });
  } catch (err) {
    return res.status(400).json({
      error: err,
    });
  }
};

// Get api for List for Drivers...!
exports.GetDrivers = async (req, res) => {
  try {
    const getdriver = await NewDrivers.find({});
    if (getdriver) {
      return res.status(201).json({
        status: true,
        message: `here are your data`,
        // countDriver: getdriver.length,
        getdriver,
        
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "your data is not available..",
        err,
      });
    }
  } catch (err) {
    console.log(err);
    return res.status(404).json({
      error: err,
    });
  }
};

// Get driver by its ObjectId(_id)!
exports.getDriverId = async (req, res) => {
  try {
    const getDriverid = await NewDrivers.findOne({ _id: req.params._id });
    console.log(getDriverid, "ggggggg");
    if (getDriverid) {
      return res.status(201).json({
        status: true,
        message: getDriverid,
      });
    } else {
      return res.status(400).json({
        status: false,
        message: "Driver not available ..!",
      });
    }
  } catch (err) {
    console.log(err);
    return res.status(400).json({
      error: err,
    });
  }
};

// delete api for Drivers...!
exports.deleteDriver = async (req, res) => {
  try {
    const driver_detail = await NewDrivers.deleteOne({ _id: req.params._id });
    console.log(driver_detail, "dddddddd");
    if (driver_detail) {
      return res.status(200).json({
        deleted: "Driver deleted successfully",
      });
    } else {
      return res.status(404).json({
        message: "your data is not available..",
      });
    }
  } catch (err) {
    console.log(err);
    return res.status(400).json({
      error: err,
    });
  }
};
