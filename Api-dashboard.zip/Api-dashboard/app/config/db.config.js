module.exports = {
    // url: "mongodb://agrix-api-server:Yo7UvAYcqaN4Y527tWafYoQoClx4KFFg13fCCxXjikYDrUvB6deSe4QMuRpoFChVYAyv0Mt7wB3GjPfRPD5KZw==@agrix-api-server.mongo.cosmos.azure.com:10255/agrix-api-database?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000"
    url:"mongodb+srv://evanjali:evan123@dashboard-cluster.u3i1c.mongodb.net/schema-data"
  };