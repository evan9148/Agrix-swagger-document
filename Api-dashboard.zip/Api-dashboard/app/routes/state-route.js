module.exports = app => {
    const States = require("../controller/state-controller");
    var router = require("express").Router();
    // Create a new deliveryHistory
    router.post("/add-states", States.createState);
    router.get("/states-data", States.getState);
   
    app.use('/api/state', router);
};