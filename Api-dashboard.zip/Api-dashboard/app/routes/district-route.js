module.exports = app => {
    const Districts = require("../controller/district-controller");
    var router = require("express").Router();

    // Create a new deliveryHistory
    router.post("/add-district", Districts.createDistrict);
    router.get("/districts-data", Districts.getDistrict);
   
    app.use('/api/district', router);
};