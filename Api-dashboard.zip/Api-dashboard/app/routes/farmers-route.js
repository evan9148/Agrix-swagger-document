module.exports = app => {
    const farmerdata = require("../controller/farmers-controller");
    var router = require("express").Router();
    // Create a new deliveryHistory
    router.post("/addfarmers", farmerdata.CreateFarmers);
    router.get("/farmerdata", farmerdata.GetFarmers);
    router.get("/farmername/:Farmerid", farmerdata.getFarmersName);
    router.get("/farmerbycluster/:clusterId", farmerdata.farmerByClusterId);
    router.put("/updatefarmers/:Farmerid", farmerdata.updateFarmers);
    router.delete("/deletefarmer/:_id", farmerdata.deleteFarmer)

    app.use('/api/farmer', router);
  };