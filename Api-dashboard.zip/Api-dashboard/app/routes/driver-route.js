module.exports = app => {
    const driverdetailsdata = require("../controller/driver-controller");
    var router = require("express").Router();
    // Create a new deliveryHistory
    router.post("/add-drivers", driverdetailsdata.createDriver);
    router.get("/driverdata", driverdetailsdata.GetDrivers);
    router.get("/driverbyid/:_id", driverdetailsdata.getDriverId);
    router.put("/updatedriver/:_id", driverdetailsdata.updateDrivers);
    router.delete("/deletedriver/:_id", driverdetailsdata.deleteDriver)
   

    app.use('/api/driver', router);
  };