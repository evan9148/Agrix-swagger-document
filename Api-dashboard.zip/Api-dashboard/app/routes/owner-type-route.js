module.exports = app => {
    const ownertypes = require("../controller/owner-type.controller");
    var router = require("express").Router();

    // Create a new deliveryHistory
    router.post("/add-ownerType", ownertypes.createOwnertype);
    router.get("/ownerType-data", ownertypes.getOwnertype);
   
    app.use('/api/owner-type', router);
}