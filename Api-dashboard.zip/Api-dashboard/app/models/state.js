module.exports = mongoose => {
    const AddState = mongoose.model(
        "state",
        mongoose.Schema(
        {
            state: {
                type: String,
            }
        },
        { timestamps: true }
      )
    );
    return AddState;
};