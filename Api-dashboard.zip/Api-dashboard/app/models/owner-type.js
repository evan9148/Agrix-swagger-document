module.exports = mongoose => {
    const Addownertype = mongoose.model(
        "owner-type",
        mongoose.Schema(
        {
            ownerType: {
                type: String,
            }
        },
        { timestamps: true }
      )
    );
    return Addownertype;
};