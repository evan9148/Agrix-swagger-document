module.exports = mongoose => {
    const driverDetails = mongoose.model(
      "drivers",
      mongoose.Schema(
        {
          driverId:String,
          firstName:String,
          lastName:String,
          contactDetails:String,
          state:String,
          clusterId:String,
          machineId:String,
          attachementId:String,
          CountDriver: Number
        },
        { timestamps: true }
      )
    );
    return driverDetails;
  };