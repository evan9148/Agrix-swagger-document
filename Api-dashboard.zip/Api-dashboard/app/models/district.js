module.exports = mongoose => {
    const Adddistrict = mongoose.model(
        "district",
        mongoose.Schema(
        {
            district: {
                type: String,
            }
        },
        { timestamps: true }
      )
    );
    return Adddistrict;
};