module.exports = mongoose => {
    const AddFarmers = mongoose.model(
        "Farmers",
        mongoose.Schema(
        {
            firstName: {
                type: String,
            },
            lastName: {
                type: String
            },
            ownerType: {
                type: String
            },
            address: {
                type: String
            },
            farmingSeason: {
                type: String
            },
            cropType: {
                type: String
            },
            cropSubType: {
                type: String
            },
            farmerId: {
                type: String
            },
            contactNo:{
                type:Number,
                min:10
            },
            clusterId:{
                type:String
            },
            countFarmer: {
                type: Number
            }
        },
        { timestamps: true }
      )
    );
    return AddFarmers;
};