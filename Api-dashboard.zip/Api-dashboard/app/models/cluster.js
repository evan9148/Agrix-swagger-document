module.exports = mongoose => {
    const AddCluster = mongoose.model(
      "Cluster",
      mongoose.Schema(
        {
            clusterCode: {
                type: String,
                unique: true
            },
            clusterid: {
                type: String,
                unique: true
            },
            clusterManager: {
                type: String
            },
            addVillages: {
                type: String
            },
            district: {
                type: String
            },
            state: {
                type: String
            },
            officeAddress: {
                type: String
            },
            contactDetails: {
                type: Number,
                min: 10
            },
            clusterLevelStat: [
                {
                    customerStat: {
                        type: String
                    },
                    sales: {
                        Type: Number
                    },
                    purchase: {
                        type: Number
                    }, 
                    expenditure: {
                        type: Number
                    }, 
                    hrBasicdetails: {
                        type: String
                    }, 
                    lead_Details: {
                        type: String
                    }
                }
            ],
            countCluster: {
                type: Number
            },
        },
        { timestamps: true }
      )
    );
    return AddCluster;
  };