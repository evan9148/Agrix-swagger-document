module.exports = mongoose => {
    const AddPlotDetails = mongoose.model(
      "Plot-details",
      mongoose.Schema(
        {
            farmerName: {
                type: String
            },
            location: {
                type: String
            },
            village: {
                type: String
            },
            district: {
                type: String
            },
            latitude: {
                type: Number
            },
            long: {
                type: Number
            },
            area_of_Plot : {
                type: String
            },
            perimeter_of_Plot: {
                type: Number
            },
            plotShape : {
                type: String
            },
            soilType : {
                type: String
            },
            nutrient_Content_Analysis: {
                type: String
            },
            waterSource : {
                type: String
            },
            plotid: {
                type: String
            },
            farmerId: {
                type: String
            },
            countPlot: {
                type: Number
            }
        },
        { timestamps: true }
      )
    );
    return AddPlotDetails;
  };