module.exports = mongoose => {
    const countDrivers = mongoose.model(
      "Count",
      mongoose.Schema(
        {
          id: {
            type: String
          },
          sequence: {
            type: Number
          }
        },
        { timestamps: true }
      )
    );
    return countDrivers;
  };