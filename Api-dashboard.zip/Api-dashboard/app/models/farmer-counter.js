module.exports = mongoose => {
    const countFarmers = mongoose.model(
      "farmerCounter",
      mongoose.Schema(
        {
          id: {
            type: String
          },
          sequence: {
            type: Number
          }
        },
        { timestamps: true }
      )
    );
    return countFarmers;
  };