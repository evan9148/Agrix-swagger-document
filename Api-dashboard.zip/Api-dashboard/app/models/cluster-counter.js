module.exports = mongoose => {
    const countCluster = mongoose.model(
      "Countcluster",
      mongoose.Schema(
        {
          id: {
            type: String
          },
          sequence: {
            type: Number
          }
        },
        { timestamps: true }
      )
    );
    return countCluster;
  };