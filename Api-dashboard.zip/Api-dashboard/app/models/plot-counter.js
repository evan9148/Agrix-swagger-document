module.exports = mongoose => {
    const countPlots = mongoose.model(
      "Countplot",
      mongoose.Schema(
        {
          id: {
            type: String
          },
          sequence: {
            type: Number
          }
        },
        { timestamps: true }
      )
    );
    return countPlots;
  };